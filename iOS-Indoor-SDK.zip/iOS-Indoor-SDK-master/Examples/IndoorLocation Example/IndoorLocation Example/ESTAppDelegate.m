//  Copyright (c) 2014 Estimote Inc. All rights reserved.

#import "ESTAppDelegate.h"

@implementation ESTAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    return YES;
}

@end
