//  Copyright (c) 2014 Estimote Inc. All rights reserved.

#import <UIKit/UIKit.h>

#import "ESTAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ESTAppDelegate class]));
    }
}
