//  Copyright (c) 2014 Estimote Inc. All rights reserved.

#import <UIKit/UIKit.h>

@interface ESTAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
