//  Copyright (c) 2014 Estimote Inc. All rights reserved.

#import <UIKit/UIKit.h>

@interface ESTMenuViewController : UIViewController

@end
